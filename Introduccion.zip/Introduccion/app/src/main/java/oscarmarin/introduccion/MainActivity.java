package oscarmarin.introduccion;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Variables de interfaz
    private TextView txtContador;
    private Button btnClick;

    private Switch toogleSwitch;

    // Variable de lógica
    private int contador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        contador = 0;
        inicializaVistas();

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (toogleSwitch.isChecked()) {
                    Toast.makeText(MainActivity.this, "El boton esta bloqueado", Toast.LENGTH_SHORT).show();
                    return;
                }
                contador++;
                txtContador.setText(contador + " veces");
                Toast.makeText(MainActivity.this, "Has pulsado el botón", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void inicializaVistas() {
        txtContador = findViewById(R.id.txtContadorMain);
        btnClick = findViewById(R.id.btnClickMain);
        toogleSwitch = findViewById(R.id.switchMain);
    }
}